import csv, re, sys
from pathlib import Path
csv_path = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('integrated_sim.csv')
src = Path(__file__).with_name('sonar_dsp.v').read_text()
coeff = [0]*63
for addr, sign, val in re.findall(r"(\d+): coefficient=(-?)16'sd(\d+);",src):
    coeff[int(addr)] = (-1 if sign else 1)*int(val)
reference = [0]*256
for addr, sign, val in re.findall(r"(\d+): lookup=(-?)14'sd(\d+);",src):
    reference[int(addr)] = (-1 if sign else 1)*int(val)
rows = list(csv.DictReader(csv_path.open()))
assert len(rows)==256, 'Expected 256 rows'
history=[0]*63
errors=[]
for i,row in enumerate(rows):
    assert int(row['sample_index'])==i
    raw=int(row['adc_raw']); assert 0<=raw<16384
    mixed=((raw-8192)*reference[i])>>13
    history=[mixed]+history[:-1]
    expected=sum(a*b for a,b in zip(history,coeff))>>15
    expected=(expected+32768)%65536-32768
    actual=int(row['filtered_signed'])
    if actual!=expected: errors.append((i,expected,actual))
print('Rows:',len(rows),'FIR mismatches:',len(errors),'First mismatches:',errors[:5])
assert not errors, 'Integrated DSP comparison failed'
print('PASS: all 256 filtered results match raw ADC samples processed by integer model')
