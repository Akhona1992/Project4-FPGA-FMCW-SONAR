INTEGRATED ADC TO DSP TEST — hardware verification pending
Open project/LED_BLINK.qpf in Quartus 25.1 Lite.
Top remains LED_BLINK; revision remains LED_BLINK.
Source/probe widths are 10/32, CTRL. GPIO assignments copied unchanged from verified ADC project.
Compile the project, inspect timing slack, then program project/output_files/LED_BLINK.sof.
No old SOF is included, to avoid accidentally programming a previous design.
Use the previously checked physical connection to Sonar v1.0. Do not alter connections while powered.
Write source 0, then 1. Wait one second. Read probe.
Probe: count[31:23], ADC state[22:19], active[18], timeout/overrun[17], done[16], sample[15:0].
Raw ADC bank: source 2*index. Filtered bank: source 512+2*index.
LED0 follows source bit 0 and turns OFF during export.
Run export_sonar_integrated.tcl after capture; upload sonar_integrated_*.csv for verification.
U2 channel 0 only feeds DSP; all 8 channel words read to reset channel pointer.
Raw unsigned ADC code is centred by subtracting 8192, multiplied by the chirp reference,
then processed by the same 63-tap FIR used in the verified synthetic DSP test.
Internal chirp reference is indexed by conversion number; this does not establish transmitter coherence.
This demonstrates an ADC-to-DSP data path. Microphone response/range/angle remain unverified.
Simulation testbench is NOT part of Quartus synthesis.
Local simulation verified 256 filtered values, exact 100 us conversion spacing, 2048 reads,
all JTAG addresses, no unintended recapture, timeout and recovery.
Keep previous verified ADC and DSP projects unchanged for submission.
