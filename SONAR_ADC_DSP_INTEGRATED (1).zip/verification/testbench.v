`timescale 1ns/1ps
module pc_control(input [31:0] probe, output [9:0] source);
reg [9:0] command=0;
assign source=command;
endmodule
module testbench;
reg clk=0;
always #10 clk=~clk;
reg eoc=0;
wire cs2,cs3,rd,wr,conv,cr0,cr1,led;
integer mode=0,index=0,reads=0,starts=0;
wire [13:0] db=(!cs2 && !rd) ? (14'd1000 + starts + index*4000) : 14'bz;
LED_BLINK #(.STARTUP_CYCLES(10)) dut(clk,led,db,eoc,eoc,cs2,cs3,rd,wr,conv,cr0,cr1);
always @(posedge conv) begin
 starts=starts+1; index=0;
 if(mode==0) begin #100 eoc=1; #2900 eoc=0; end
 else if(mode==2) eoc=1;
end
always @(posedge rd) if(!cs2) begin index=index+1; reads=reads+1; end
always @(negedge clk) begin
 if(cs3!==1 || wr!==1 || cr0!==0 || cr1!==0) $fatal(1,"Unsafe fixed controls");
 if(!cs2 && conv) $fatal(1,"Selected ADC during conversion");
end
task trigger;
begin
 dut.u_pc_control.command=0; #200;
 dut.u_pc_control.command=1; #200;
end
endtask
time previous_start=0;
integer interval_checks=0;
always @(posedge conv) begin
 if (previous_start != 0 && dut.completed_count != 0) begin
  if ($time-previous_start != 100000) $fatal(1,"Uneven sample interval: %0t",$time-previous_start);
  interval_checks=interval_checks+1;
 end
 previous_start=$time;
end
integer j, fd;
initial begin
 #1000; trigger; #26000000;
 if(!dut.done || dut.timeout_error || dut.overrun_error || reads!=2048 || dut.completed_count!=256 || starts!=256 || interval_checks!=255) $fatal(1,"Capture failed");
 fd=$fopen("integrated_sim.csv","w");
 $fdisplay(fd,"sample_index,adc_raw,filtered_signed");
 for(j=0;j<256;j=j+1) $fdisplay(fd,"%0d,%0d,%0d",j,dut.sample_memory[j],$signed(dut.sample_memory[256+j]));
 $fclose(fd);
 for(j=0;j<512;j=j+1) begin
  dut.u_pc_control.command=j*2; #200;
  if(dut.probe_data[15:0] !== dut.sample_memory[j]) $fatal(1,"Readback failed at %0d",j);
 end
 #100000;
 if(starts!=256) $fatal(1,"Unwanted recapture");
 mode=1; eoc=0; trigger; #1100000;
 if(!dut.timeout_error || dut.done || dut.capture_active || conv || !cs2) $fatal(1,"Timeout failed");
 mode=0; eoc=0; trigger; #26000000;
 if(!dut.done || dut.timeout_error || dut.completed_count!=256 || dut.overrun_error) $fatal(1,"Recovery failed");
 $display("PASS: integrated capture 256 pairs, 100 us spacing, 2048 reads, all 512 addresses, no repeat, timeout and recovery");
 $finish;
end
endmodule
