# Read Integrated ADC raw/FIR results ONLY; never trigger a capture.
# Run with quartus_stp -t export_sonar_integrated.tcl, or Tools > Tcl Scripts.
# A GUI/other Quartus host forwards this script to its sibling quartus_stp.
if {[llength [info commands start_insystem_source_probe]] == 0} {
    set runner [file join [file dirname [info nameofexecutable]] quartus_stp.exe]
    if {![file exists $runner]} {
        set runner [file join [file dirname [info nameofexecutable]] quartus_stp]
    }
    if {![file exists $runner]} {
        error "Cannot locate quartus_stp beside this executable. Run this script using quartus_stp -t."
    }
    puts [exec $runner -t [file normalize [info script]] 2>@1]
    return
}

proc read_capture_word {index} {
    set raw [string trim [read_probe_data -instance_index $index -value_in_hex]]
    regsub -nocase {^0x} $raw {} raw
    if {![regexp {^[0-9a-fA-F]{1,8}$} $raw]} {
        error "Unexpected probe format: $raw"
    }
    scan $raw %x word
    return [expr {$word & 0xffffffff}]
}

proc require_complete {word} {
    set count [expr {($word >> 23) & 511}]
    set state [expr {($word >> 19) & 15}]
    set active [expr {($word >> 18) & 1}]
    set timeout [expr {($word >> 17) & 1}]
    set done [expr {($word >> 16) & 1}]
    
    if {$count != 256 || $state != 1 || $active || !$done || $timeout} {
        error "Capture not ready: count=$count state=$state active=$active done=$done timeout=$timeout"
    }
}

set cables [get_hardware_names]
if {[llength $cables] != 1} {
    error "Expected one JTAG cable; found: $cables. Disconnect other cables and retry."
}
set cable [lindex $cables 0]
set devices [get_device_names -hardware_name $cable]
if {[llength $devices] != 1} {
    error "Expected one JTAG device; found: $devices"
}
set device [lindex $devices 0]
set matches {}
foreach item [get_insystem_source_probe_instance_info -hardware_name $cable -device_name $device] {
    if {[lindex $item 3] eq "CTRL" && [lindex $item 1] == 10 && [lindex $item 2] == 32} {
        lappend matches [lindex $item 0]
    }
}
if {[llength $matches] != 1} {
    error "Expected one CTRL instance with source width 10 and probe width 32. Program the 256-sample design first."
}
set index [lindex $matches 0]
set session_open 0
set csv_channel ""
set output_path ""
set failed [catch {
    start_insystem_source_probe -hardware_name $cable -device_name $device
    set session_open 1
    require_complete [read_capture_word $index]
    # Every source value below is EVEN, so command bit 0 stays low.
    write_source_data -instance_index $index -value 000 -value_in_hex
    after 2
    set stamp [clock format [clock seconds] -format %Y%m%d_%H%M%S]
    set output_path [file join [file dirname [file normalize [info script]]] "sonar_integrated_${stamp}_[clock clicks -milliseconds].csv"]
    set csv_channel [open $output_path {WRONLY CREAT EXCL}]
    puts $csv_channel "sample_index,time_us,adc_raw,filtered_signed"
    for {set sample_index 0} {$sample_index < 256} {incr sample_index} {
        set pair {}
        for {set channel 0} {$channel < 2} {incr channel} {
            set source_value [expr {$channel * 512 + $sample_index * 2}]
            write_source_data -instance_index $index -value [format %03X $source_value] -value_in_hex
            after 2
            set word [read_capture_word $index]
            require_complete $word
            set second [read_capture_word $index]
            if {$word != $second} {error "Probe changed at sample $sample_index channel $channel"}
            set value [expr {$word & 65535}]
            if {$channel == 1 && $value >= 32768} {set value [expr {$value-65536}]}
            lappend pair $value
        }
        puts $csv_channel "$sample_index,[expr {$sample_index * 100}],[lindex $pair 0],[lindex $pair 1]"
    }
    close $csv_channel
    set csv_channel ""
} message]

# Release JTAG even if a read failed; remove any partial CSV.
if {$csv_channel ne ""} {catch {close $csv_channel}}
if {$session_open} {
    catch {write_source_data -instance_index $index -value 000 -value_in_hex}
    catch {end_insystem_source_probe}
}
if {$failed} {
    if {$output_path ne ""} {catch {file delete $output_path}}
    error $message
}
puts "SUCCESS: exported 256 stored sample pairs (512 readings)."
puts "CSV: $output_path"
puts "Time column assumes the 50 MHz clock and 5000-cycle sample period."
puts "Integrated ADC-to-DSP capture. Acoustic response and ranging remain unverified. No new capture was triggered."
