// DIGITAL SELF-TEST ONLY: no external ADC or speaker connections.
// 256 samples at 10 ksample/s, repeating triangular-frequency chirp ROM.
// source[0] rising: start; source[8:1]: address; source[9]: mixed(0)/FIR(1).
module SONAR_DSP_TEST #(parameter integer PERIOD=5000)(
 input wire CLOCK_50, output wire LED0);
 wire [9:0] source;
 reg [9:0] meta=0, sync=0;
 reg previous=0;
 always @(posedge CLOCK_50) begin meta<=source; sync<=meta; previous<=sync[0]; end
 wire start=sync[0] && !previous;
 reg active=0, done=0; reg [8:0] count=0;
 reg [12:0] timer=0; reg [7:0] index=0;
 wire valid=active && timer==PERIOD-1;
 wire clear=start && !active;
 wire [7:0] echo_address=index-8'd16;
 wire signed [13:0] reference, echo;
 sonar_chirp_rom ref_rom(index,reference);
 sonar_chirp_rom echo_rom(echo_address,echo);
 wire output_valid; wire signed [15:0] mixed, filtered;
 sonar_dsp dsp(CLOCK_50,clear,valid,echo,reference,output_valid,mixed,filtered);
 reg [15:0] memory[0:511]; reg [15:0] selected=0;
 always @(posedge CLOCK_50) begin
  if(done) selected<=memory[sync[9:1]]; else selected<=0;
  if(clear) begin active<=1; done<=0; count<=0; timer<=0; index<=0; end
  else if(active) begin
   if(valid) timer<=0; else timer<=timer+1'b1;
   if(output_valid) begin
    memory[{1'b0,index}]<=mixed;
    memory[{1'b1,index}]<=filtered;
    count<=count+1'b1;
    if(index==255) begin active<=0; done<=1; end
    else index<=index+1'b1;
   end
  end
 end
 assign LED0=sync[0];
 wire [3:0] state=active?4'd2:4'd1;
 // [31:23] count, [22:19] state, [18] active, [17] zero, [16] done,
 // [15:0] signed sample. ADC exporter cannot decode this format.
 wire [31:0] probe={count,state,active,1'b0,done,selected};
 pc_control u_pc_control(.probe(probe),.source(source));
endmodule
