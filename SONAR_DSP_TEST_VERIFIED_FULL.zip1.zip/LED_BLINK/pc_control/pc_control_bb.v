
module pc_control (
	probe,
	source);	

	input	[31:0]	probe;
	output	[9:0]	source;
endmodule
