module LED_BLINK (
    input  wire CLOCK_50,
    output wire LED0
);

    wire pc_command;

    // Synchronize the JTAG command to the board clock.
    (* async_reg = "true" *) reg command_meta = 1'b0;
    (* async_reg = "true" *) reg command_sync = 1'b0;

    always @(posedge CLOCK_50) begin
        command_meta <= pc_command;
        command_sync <= command_meta;
    end

    pc_control u_pc_control (
        .probe  (command_sync),
        .source (pc_command)
    );

    assign LED0 = command_sync;

endmodule