import csv
from pathlib import Path
p=Path(__file__).parent
expected=list(csv.DictReader((p/'expected_simulation.csv').open()))
actual=list(csv.DictReader((p/'rtl_simulation.csv').open()))
assert len(expected)==len(actual)==256
for e,a in zip(expected,actual):
    for key in ('sample_index','time_us','mixed','filtered'):
        assert int(e[key])==int(a[key]),(key,e,a)
print('PASS: all 512 outputs agree with integer model')
