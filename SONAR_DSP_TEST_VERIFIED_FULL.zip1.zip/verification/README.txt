SONAR FPGA DSP SELF-TEST - DIGITAL SYNTHETIC INPUT ONLY

Keep the verified two-channel ADC project as a backup.
Make another full project-folder copy for this test, called SONAR_DSP_TEST.
Copy SONAR_DSP_TEST.v, sonar_dsp.v and export_sonar_dsp.tcl into the
copied project's folder containing LED_BLINK.qpf. Reuse its generated
pc_control IP (10-bit source / 32-bit probe); do not regenerate it.
Open the COPIED LED_BLINK.qpf. Add both new .v files under
Project > Add/Remove Files in Project. Set SONAR_DSP_TEST as top-level
entity under Assignments > Settings > General. Keep revision LED_BLINK.
Clock CLOCK_50=P11 and LED0=A8 assignments and existing SDC apply.
Remove obsolete ADC_* pin/I/O assignments in this COPY if Quartus warns
that those ports are absent. Leave unused pins As input tri-stated.
Compile. Hardware verification has NOT yet been performed.

Program the copied project's newly compiled output_files/LED_BLINK.sof.
Open In-System Sources and Probes, scan, select CTRL.
Source 0 then 1 starts one capture. Wait at least 0.1 second.
Run export_sonar_dsp.tcl using Tools > Tcl Scripts. CSV stores signed
mixer/FIR pairs. The previous ADC exporter is incompatible with this design.
Do not add testbench.v to the Quartus synthesis project: its pc_control
module is only a simulation stub. Use actual generated IP for hardware.

Architecture:
50 MHz clock / 5000 = 10 ksample/s enable.
256-entry signed 14-bit cosine ROM with triangular instantaneous-frequency
sequence from 1 kHz to 3 kHz and back (128 samples per half-sweep).
Receive test signal is this same ROM circularly delayed by 16 samples
(1.6 ms), amplitude 7000 counts. Circular-record boundary is artificial;
this is not a validated continuous-phase transmitter or acoustic echo.
Signed 14x14 mixer product shifts right 13 into signed 16 bits.
63-tap Hamming-window low-pass FIR, design cutoff 600 Hz at 10 ksample/s,
Q15 coefficients normalized to sum 32768. Sequential one-tap-per-clock
MAC with 48-bit accumulator. Arithmetic right shift by 15 produces output.
Filter has 31-sample / 3.1 ms group delay; initial history is zero.
Each output takes 63 MAC clocks after sample acceptance. No decimation.
512 x 16-bit results RAM: mixed[0:255], filtered[256:511].
JTAG source bit0 start; bits8:1 index; bit9 selects mixed(0)/filtered(1).
Probe count[31:23], state[22:19], active[18], zero[17], done[16],
signed result[15:0]. Addresses must settle before probe reading.

Validation already run:
Icarus Verilog simulation produced rtl_simulation.csv.
All 512 outputs exactly equal expected_simulation.csv integer model.
Held-start command protection and capture restart passed.
The supplied baseline expected CSV is simulation evidence, not measured data.
Quartus resource usage, timing and actual FPGA output still need validation.
The ADC acquisition module remains a separate verified design; this package
has NO external ADC interface, PWM output, speaker drive or DoA estimator.
Do not describe it as a complete functioning sonar system.

Limitations to report:
Intended microphone 490-CMEJ-0415-42-P was unavailable. Substitute capsule
had incompatible mechanical format and lecturer-reported lower sensitivity.
MK1 +B measured 0 V despite supply present; bias fault cause unresolved.
Sound response not established. Lowest recorded 5 V rail was 4.745 V,
slightly below ADC's 4.75 V specified minimum; meter accuracy unverified.
Earlier ADC captures establish digital capture/export, not analog calibration.
Physical triangular-array angle and acoustic range are not verified.
