`timescale 1ns/1ps
module pc_control(input wire [31:0] probe,output reg [9:0] source=0); endmodule
module testbench;
 reg clk=0; always #10 clk=~clk;
 wire led; SONAR_DSP_TEST dut(clk,led);
 integer f,i;
 initial begin
  f=$fopen("rtl_simulation.csv","w");
  $fwrite(f,"sample_index,time_us,mixed,filtered\n");
  #200;dut.u_pc_control.source=1;
  wait(dut.done);#200;
  if(dut.count!=256) $fatal(1,"Bad count");
  for(i=0;i<256;i=i+1)
   $fwrite(f,"%0d,%0d,%0d,%0d\n",i,i*100,$signed(dut.memory[i]),$signed(dut.memory[256+i]));
  $fclose(f);
  #100000;if(dut.count!=256) $fatal(1,"Repeated capture");
  dut.u_pc_control.source=0;#200;dut.u_pc_control.source=1;
  wait(dut.active);wait(dut.done);
  if(dut.count!=256) $fatal(1,"Restart failed");
  $display("PASS: 256 DSP results, held-command protection, restart");$finish;
 end
 initial begin #60000000;$fatal(1,"Timeout");end
endmodule
