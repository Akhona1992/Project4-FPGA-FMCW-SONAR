// MAX11059 U2: 256 sample pairs (U2 channels 0 and 1) at 10 ksample/s, 50 MHz clock.
// pc_control requires a 10-bit source and 32-bit probe.
// Source bit 0 rising starts a capture; bits 8:1 select a stored sample; bit 9 selects channel 0/1.
// Write channel*512 + address*2 with bit 0 clear to inspect samples after done.
// Data is raw/un-calibrated; valid only when done is asserted.
// Shared CONVST also converts U3, but only U2 is read.
// Uses ADC power-on defaults; WR remains high and the FPGA never drives DB.
module LED_BLINK #(
    parameter integer STARTUP_CYCLES = 5000000,
    parameter integer SAMPLE_PERIOD_CYCLES = 5000
) (
    input wire CLOCK_50,
    output wire LED0,
    input wire [13:0] ADC_DB,
    input wire ADC_EOC_U2,
    input wire ADC_EOC_U3,
    output wire ADC_CS_U2_N,
    output wire ADC_CS_U3_N,
    output wire ADC_RD_N,
    output wire ADC_WR_N,
    output wire ADC_CONVST,
    output wire ADC_CR0,
    output wire ADC_CR1
);
    localparam [3:0] BOOT = 0, IDLE = 1, ACQUIRE = 2,
        PULSE = 3, WAIT_BUSY = 4, WAIT_DONE = 5,
        CS_SETUP = 6, READ_LOW = 7, READ_HIGH = 8, GAP = 9;

    wire [9:0] pc_source;
    wire pc_command = pc_source[0];
    reg [8:0] address_meta = 0, address_sync = 0;
    always @(posedge CLOCK_50) begin
        address_meta <= pc_source[9:1];
        address_sync <= address_meta;
    end
    reg command_meta = 0, command_sync = 0, command_previous = 0;
    reg [1:0] eoc_meta = 0, eoc_sync = 0;
    always @(posedge CLOCK_50) begin
        command_meta <= pc_command;
        command_sync <= command_meta;
        command_previous <= command_sync;
        eoc_meta <= {ADC_EOC_U3, ADC_EOC_U2};
        eoc_sync <= eoc_meta;
    end
    wire request = command_sync && !command_previous;

    reg [3:0] state = BOOT;
    reg [22:0] startup_timer = 0;
    reg [15:0] timer = 0;
    reg [2:0] channel_index = 0;
    reg done = 0, timeout_error = 0, busy_seen = 0;
    reg [8:0] completed_count = 0;
    reg [13:0] sample_memory [0:511];
    reg [13:0] selected_sample = 0;
    reg [31:0] period_remaining = 0;
    reg capture_active = 0, overrun_error = 0;
    // Synchronous read: allow the address to settle before reading the probe.
    always @(posedge CLOCK_50) begin
        if (done) selected_sample <= sample_memory[address_sync];
        else selected_sample <= 0;
    end

    assign ADC_CS_U2_N = !((state == CS_SETUP) ||
                           (state == READ_LOW) || (state == READ_HIGH));
    assign ADC_CS_U3_N = 1'b1;
    assign ADC_RD_N = (state != READ_LOW);
    assign ADC_WR_N = 1'b1;
    assign ADC_CONVST = (state == PULSE) ||
                        (state == WAIT_BUSY) || (state == WAIT_DONE);
    assign ADC_CR0 = 1'b0;
    assign ADC_CR1 = 1'b0;
    assign LED0 = command_sync;

    always @(posedge CLOCK_50) begin
        if (capture_active && period_remaining != 0)
            period_remaining <= period_remaining - 1'b1;
        case (state)
            BOOT: begin
                // 100 ms startup guard at the default parameter value.
                if (startup_timer == STARTUP_CYCLES - 1) begin
                    state <= IDLE;
                    startup_timer <= 0;
                end else startup_timer <= startup_timer + 1'b1;
            end
            IDLE: begin
                timer <= 0;
                if (request) begin
                    done <= 0;
                    timeout_error <= 0;
                    busy_seen <= 0;
                    completed_count <= 0;
                    capture_active <= 1;
                    overrun_error <= 0;
                    channel_index <= 0;
                    state <= ACQUIRE;
                end
            end
            ACQUIRE: begin
                // 2 us acquisition and quiet time, with CS/RD/WR high.
                if (timer == 99) begin
                    timer <= 0;
                    state <= PULSE;
                    period_remaining <= SAMPLE_PERIOD_CYCLES - 1;
                end else timer <= timer + 1'b1;
            end
            PULSE: begin
                // Observe EOC high during the first 1 us after CONVST rises.
                if (eoc_sync[0]) busy_seen <= 1;
                if (timer == 49) begin
                    timer <= 0;
                    if (busy_seen || eoc_sync[0]) state <= WAIT_DONE;
                    else state <= WAIT_BUSY;
                end else timer <= timer + 1'b1;
            end
            WAIT_BUSY: begin
                if (eoc_sync[0]) begin
                    busy_seen <= 1;
                    timer <= 0;
                    state <= WAIT_DONE;
                end else if (timer == 49999) begin
                    timeout_error <= 1;
                    capture_active <= 0;
                    timer <= 0;
                    state <= IDLE;
                end else timer <= timer + 1'b1;
            end
            WAIT_DONE: begin
                if (!eoc_sync[0]) begin
                    timer <= 0;
                    state <= CS_SETUP;
                end else if (timer == 49999) begin
                    timeout_error <= 1;
                    capture_active <= 0;
                    timer <= 0;
                    state <= IDLE;
                end else timer <= timer + 1'b1;
            end
            CS_SETUP: begin
                // Select U2, then wait 1 us before asserting RD.
                if (timer == 49) begin
                    timer <= 0;
                    state <= READ_LOW;
                end else timer <= timer + 1'b1;
            end
            READ_LOW: begin
                // Bus is held stable by the ADC throughout this 1 us read.
                // Capture before RD rises; do not synchronize data bit by bit.
                if (timer == 49) begin
                    if (channel_index < 2) begin
                        sample_memory[{channel_index[0], completed_count[7:0]}] <= ADC_DB;
                    end
                    timer <= 0;
                    state <= READ_HIGH;
                end else timer <= timer + 1'b1;
            end
            READ_HIGH: begin
                // Each RD rising edge advances the ADC channel pointer.
                if (timer == 49) begin
                    timer <= 0;
                    if (channel_index == 7) begin
                        completed_count <= completed_count + 1'b1;
                        if (completed_count == 255) begin
                            done <= 1;
                            capture_active <= 0;
                            state <= IDLE;
                        end else if (period_remaining <= 100) begin
                            // Stop instead of silently producing irregular samples.
                            overrun_error <= 1;
                            capture_active <= 0;
                            state <= IDLE;
                        end else state <= GAP;
                    end else begin
                        channel_index <= channel_index + 1'b1;
                        state <= READ_LOW;
                    end
                end else timer <= timer + 1'b1;
            end
            GAP: begin
                // Start the 2 us acquisition so the next CONVST edge is
                // exactly SAMPLE_PERIOD_CYCLES clocks after the previous edge.
                if (period_remaining == 100) begin
                    timer <= 0;
                    channel_index <= 0;
                    busy_seen <= 0;
                    state <= ACQUIRE;
                end
            end
            default: begin
                state <= IDLE;
                timer <= 0;
                timeout_error <= 1;
                capture_active <= 0;
            end
        endcase
    end

    // [31:23] complete conversions, 0..256
    // [22:19] state (1 idle), [18] capturing, [17] timeout
    // [16] capture done, [15] command, [14] sampling-period overrun
    // [13:0] stored raw sample: source bit 9 = channel, bits 8:1 = index (zero until done)
    wire [31:0] probe_data = {completed_count, state, capture_active,
        timeout_error, done, command_sync, overrun_error, selected_sample};
    pc_control u_pc_control (.probe(probe_data), .source(pc_source));
endmodule
